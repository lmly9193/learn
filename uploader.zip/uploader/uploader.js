import mime from "https://cdn.skypack.dev/mime";


(function () {

    function tap(value, callback) {
        callback(value);
        return value;
    }

    function $el(element, properties) {
        return Object.assign(document.createElement(element), properties);
    }

    function toByte(size) {
        const unit = size.replace(/[^bkmgtpezy]/gi, '');
        size = parseFloat(size.replace(/[^0-9.]/g, ''));
        return (unit) ? Math.round(size * Math.pow(1024, 'bkmgtpezy'.indexOf(unit[0].toLowerCase()))) : Math.round(size);
    }

    function toReadable(size) {
        function log(number, base = Math.E) {
            return Math.log(number) / Math.log(base);
        }

        function round(number, precision = 0) {
            const factor = Math.pow(10, precision);
            return Math.round(number * factor) / factor;
        };

        const units = ['B', 'kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
        if (!size) return 0 + units[0];
        const exponent = Math.floor(log(size, 1024));
        return round(size / Math.pow(1024, exponent), 2) + units[exponent];
    }

    /*
    |--------------------------------------------------------------------------
    | 初始化
    |--------------------------------------------------------------------------
    */

    const dynamicGallery = lightGallery(document.querySelector('#lightGallery'), {
        addClass: 'lightGallery',
        download: false,
        dynamic: true,
        dynamicEl: [],
        licenseKey: '8888-8888-888-8888',
        plugins: [
            lgZoom,
            // lgThumbnail,
            lgRotate,
            lgFullscreen,
            // lgHash,
        ],
        speed: 500,
        mobileSettings: {
            controls: true,
            showCloseIcon: true,
            download: false
        },
    });

    /*
    |--------------------------------------------------------------------------
    | 事件進入點
    |--------------------------------------------------------------------------
    */

    document.querySelectorAll('input[type="file"].tct').forEach(function (node) {
        const wrapper = tap($el('div', { className: (node.multiple) ? 'wrapper multiple' : 'wrapper' }), function (wrapper) {

            const create = $el('button', { className: 'btn-create invisible', type: 'button' });
            wrapper.append(create);

            Object.assign(wrapper.dataset, { ...node.dataset });

            wrapper.input = node;
            wrapper.limit = {
                qty: () => (node.multiple) ? parseInt(node.dataset.qty) : 1,
                size: () => toByte(node.dataset.size || ''),
                accept: () => node.accept,
                multiple: () => node.multiple,
                required: () => node.required,
            };
            wrapper.original = {
                input: node.outerHTML,
                create: create.outerHTML,
            };
        });

        node.replaceWith(wrapper);
        node.onchange = inputOnChange.bind(wrapper);

        wrapper.validate = validator;

        wrapper.query = {
            create: () => wrapper.querySelector('.btn-create'),
            thumbs: () => wrapper.querySelectorAll('.thumb'),
        };

        wrapper.current = {
            qty: () => wrapper.query.thumbs().length,
            size: () => Array.from(wrapper.query.thumbs()).reduce((accumulator, thumb) => accumulator + thumb.current.size(), 0),
        };

        new MutationObserver(wrapperOnChange.bind(wrapper)).observe(wrapper, { childList: true });
    });

    /*
    |--------------------------------------------------------------------------
    | Input onChange Callback
    |--------------------------------------------------------------------------
    */
    function inputOnChange(event) {
        // wrapper = this;
        for (const file of this.input.files) {
            const input = tap(this.input.cloneNode(true), function (input) {
                ['class', 'data-qty', 'data-size', 'accept', 'multiple', 'required'].map(attribute => input.removeAttribute(attribute));
                const dt = new DataTransfer();
                dt.items.add(file);
                input.files = dt.files;
            });
            this.insertBefore(newThumb(input), this.query.create());
        }
        this.input.value = '';
    }

    function wrapperOnChange(mutationsList, observer) {
        // wrapper = this; console.log(this);
        observer.disconnect();
        validator.bind(this)();
        observer.observe(this, { childList: true });
    }

    function validator() {
        // wrapper = this; console.log(this);
        const { current, limit, query } = this;
        const { thumbs, create } = query;

        if (current.qty() > limit.qty()) {
            alert(`已超出檔案數量上限（${limit.qty()}個）`);
            Array.from(thumbs()).slice(limit.qty(), current.qty()).forEach((thumb) => thumb.remove());
        }
        
        if (current.size() > limit.size()) {
            const originalSize = current.size();
            for (let index = thumbs().length - 1; index >= 0; index--) {
                if (current.size() > limit.size()) {
                    thumbs().item(index).remove();
                }
            }
            if (current.qty() === 0) {
                alert(`你選擇的檔案超過上傳大小限制（${toReadable(originalSize)}／${toReadable(limit.size())}）`);
            } else {
                alert(`你選擇的檔案已經接近上傳大小限制（${toReadable(current.size())}／${toReadable(limit.size())}），剩餘 ${toReadable(limit.size() - current.size())} 可用。`);
            }
        }

        create().classList.toggle('invisible', (current.qty() === 0 || current.qty() >= limit.qty() || current.size() >= limit.size()));
        create().classList.toggle('d-none', (current.qty() >= limit.qty()));
        this.classList.toggle('invalid', (limit.required() && current.qty() === 0));

        this.input.disabled = (current.qty() >= limit.qty() || current.size() >= limit.size());

        return (!(limit.required() && current.qty() === 0) && !(current.qty() > limit.qty()) && !(current.size() > limit.size()));
    }

    /*
    |--------------------------------------------------------------------------
    | 事件代理
    |--------------------------------------------------------------------------
    */
    document.addEventListener('click', function (event) {
        const target = event.target;

        const wrapper = target.closest('.wrapper');
        if (wrapper) {
            if ((target === wrapper && wrapper.current.qty() === 0) || target === wrapper.querySelector('button.btn-create')) {
                wrapper.input.click();
            }

            const thumb = target.closest('.thumb');
            if (thumb) {

                if (target === thumb) {
                    const dynamicEls = Array.from(wrapper.query.thumbs()).map(thumb => thumb.dynamicEl()).filter(thumb => typeof (thumb) !== 'undefined');
                    const index = dynamicEls.findIndex(dynamicEl => (typeof (thumb.dynamicEl()) !== 'undefined' && dynamicEl.index === thumb.index()));
                    dynamicGallery.refresh(dynamicEls);
                    if (index !== -1) dynamicGallery.openGallery(index);
                }

                if (target === thumb.querySelector('button.delete')) {
                    thumb.remove();
                }

                if (target === thumb.querySelector('button.download')) {
                    const download = target;
                    console.log(download);
                    window.open(thumb.blob, '_blank');
                }
            }
        }
    });

    document.addEventListener('submit', function (event) {
        const form = event.target;
        const hasWrapper = form.querySelectorAll('.wrapper');

        if (hasWrapper.length) {
            let validate = true;
            hasWrapper.forEach(function (wrapper) {
                validate &= wrapper.validate();
            });

            if (!validate) {
                event.preventDefault();
                console.error('Form validate failure!');
            } else {
                console.info('Form submit!');
            }
        }
    });

    /*
    |--------------------------------------------------------------------------
    | 函數
    |--------------------------------------------------------------------------
    */
    function newThumb(input) {

        const thumb = tap($el('div', { className: 'thumb' }), function (thumb) {

            thumb.input = input;
            thumb.blob = URL.createObjectURL(input.files[0]);

            thumb.index = () => Array.from(thumb.query.wrapper().query.thumbs()).indexOf(thumb);

            thumb.current = {
                size: () => input.files[0].size,
                pathinfo: () => pathinfo(input.files[0].name),
                basename: () => thumb.current.pathinfo()['basename'],
                extension: () => thumb.current.pathinfo()['extension'],
                filename: () => thumb.current.pathinfo()['filename'],
                mime: () => mime.getType(input.files[0].name) || '',
                type: () => thumb.current.mime().split('/')[0],
                subtype: () => thumb.current.mime().split('/')[1],
            };

            thumb.innerHTML += `<button class="download" type="button"></button>`;
            thumb.innerHTML += `<button class="delete" type="button"></button>`;
            thumb.innerHTML += `<label class="filename">${input.files[0].name}</label>`;
            thumb.append(input);
        });

        const { type, subtype, extension } = thumb.current;

        thumb.query = {
            wrapper: () => thumb.closest('.wrapper'),
            download: () => thumb.querySelector('button.download'),
            delete: () => thumb.querySelector('button.delete'),
            filename: () => thumb.querySelector('label.filename'),
        };

        thumb.type = {
            isText: () => (type() === 'text' || extension() === 'log' || extension() === 'dat'),
            isImage: () => (type() === 'image'),
            isApplication: () => (type() === 'application'),
            isPdf: () => ['pdf'].includes(subtype()),
            isArchive: () => (thumb.type.isZip() || thumb.type.isRar() || thumb.type.is7z()),
            isZip: () => ['zip', 'x-zip-compressed'].includes(subtype()),
            isRar: () => ['vnd.rar', 'x-rar', 'x-rar-compressed'].includes(subtype()),
            is7z: () => ['x-7z-compressed'].includes(subtype()) || extension() === '7z',
            isMSG: () => (extension() === 'msg' || ['vnd.ms-outlook'].includes(subtype())),
            isMsDoc: () => (thumb.type.isWord() || thumb.type.isExcel() || thumb.type.isPowerPoint()),
            isWord: () => ['msword', 'vnd.openxmlformats-officedocument.wordprocessingml.document'].includes(subtype()),
            isExcel: () => ['vnd.ms-excel', 'vnd.openxmlformats-officedocument.spreadsheetml.sheet'].includes(subtype()),
            isPowerPoint: () => ['vnd.ms-powerpoint', 'vnd.openxmlformats-officedocument.presentationml.presentation'].includes(subtype()),
        };

        const fa5 = { pdf: '\uf1c1', word: '\uf1c2', excel: '\uf1c3', powerpoint: '\uf1c4', image: '\uf1c5', archive: '\uf1c6', audio: '\uf1c7', video: '\uf1c8', code: '\uf1c9', file: '\uf15b', alt: '\uf15c' };

        thumb.dataset.icon = fa5.file;

        if (thumb.type.isImage()) {
            const img = $el('img');
            img.src = thumb.blob;
            img.onload = function () {
                delete thumb.dataset.icon;
                if (img.naturalWidth > 240) thumb.style.backgroundSize = 'contain';
                thumb.style.backgroundImage = `url('${thumb.blob}')`;
            };
            img.onerror = () => thumb.dataset.icon = fa5.image;
            img.remove();
        }

        if (thumb.type.isText()) thumb.dataset.icon = fa5.alt;
        if (thumb.type.isPdf()) thumb.dataset.icon = fa5.pdf;
        if (thumb.type.isArchive()) thumb.dataset.icon = fa5.archive;
        if (thumb.type.isWord()) thumb.dataset.icon = fa5.word;
        if (thumb.type.isExcel()) thumb.dataset.icon = fa5.excel;
        if (thumb.type.isPowerPoint()) thumb.dataset.icon = fa5.powerpoint;

        thumb.dynamicEl = function () {
            let dynamicEl = undefined;
            const index = thumb.index();

            if (thumb.type.isText()) {
                dynamicEl = {
                    index,
                    src: `./plugins/highlight.js/viewer.html?file=${encodeURIComponent(thumb.blob)}`,
                    iframe: true,
                    subHtml: `<h4>${thumb.current.basename()}</h4>`,
                };
            }

            if (thumb.type.isImage()) {
                dynamicEl = {
                    index,
                    src: thumb.blob,
                    thumb: thumb.blob,
                    subHtml: `<h4>${thumb.current.basename()}</h4>`,
                };
            }

            if (thumb.type.isPdf()) {
                dynamicEl = {
                    index,
                    src: `./plugins/pdfjs/web/viewer.html?file=${encodeURIComponent(thumb.blob)}`,
                    iframe: true,
                    subHtml: `<h4>${thumb.current.basename()}</h4>`,
                };
            }

            if (thumb.type.isArchive()) {
                dynamicEl = {
                    index,
                    src: `./plugins/filing/viewer.html?file=${encodeURIComponent(thumb.blob)}`,
                    iframe: true,
                    subHtml: `<h4>${thumb.current.basename()}</h4>`,
                };
            }

            if (thumb.type.isMSG()) {
                dynamicEl = {
                    index,
                    src: `./plugins/msg.reader/viewer.html?file=${encodeURIComponent(thumb.blob)}`,
                    iframe: true,
                    subHtml: `<h4>${thumb.current.basename()}</h4>`,
                };
            }

            return dynamicEl;
        };

        return thumb;
    }
})();
