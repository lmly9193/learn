/**
 * @overview Utility Libraries for Responsive Design
 *
 * @author Ethan Liao
 * @copyright Copyright (c) 2023 Ethan Liao
 * @license MIT License
 * @version 1.0.0
 * @modified March 13, 2023
 */

/**
 * Ethan's Utilities
 */

class _Demo {

    #hello = '私有變數';
    hello = '公有變數';

    constructor(name, age) {
        this.name = name;
        this.age = age;
    }

    #world() {
        return `這是一個私有方法`;
    }

    world() {
        return `這是一個公有方法`;
    }
}

class _Laravel {
    async route(name, parameters) {
        const url = new URL("{{ route('shared_information.route') }}");
        const params = new URLSearchParams(parameters);

        url.searchParams.append('name', name);
        url.searchParams.append('parameters', params.toString());

        try {
            const response = await fetch(url.href);
            return await response.text();
        } catch (error) {
            return console.error('error', error);
        }
    }
}

class _Dialog {

    addConfirmationToExternalLinks() {
        const NEW_WINDOW = '_blank';
        const CONFIRMATION_MESSAGE = '您即將前往另一個網站，是否繼續前往？';
        const externalLinks = document.getElementsByTagName('a');
        Array.from(externalLinks).forEach(externalLink => {
            if (externalLink.host !== window.location.host) {
                externalLink.addEventListener('click', event => {
                    event.preventDefault();
                    const userConfirmation = confirm(CONFIRMATION_MESSAGE);
                    if (userConfirmation) {
                        window.open(externalLink.href, NEW_WINDOW);
                    }
                });
            }
        });
    }
}

class _ResourceLoader {

    loadScript(src, properties) {
        const script = Object.assign(document.createElement('script'), { src: src, ...properties });
        document.head.appendChild(script);
        console.info(`Loaded: ${src}`);
    }

    loadCSS(href, properties) {
        const link = Object.assign(document.createElement('link'), { href: href, rel: 'stylesheet', ...properties });
        document.head.appendChild(link);
        console.info(`Loaded: ${href}`);
    }
}

class _Timer {
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}
